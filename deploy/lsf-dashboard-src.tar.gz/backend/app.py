#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
IBM LSF 作业监控 Dashboard 后端
兼容 Python 2.7.5
"""

import os
import sys
import subprocess
import json
import socket
import platform
from datetime import datetime
from flask import Flask, jsonify, request, render_template, send_from_directory
from flask_cors import CORS

app = Flask(__name__, 
            static_folder='../frontend/dist',
            template_folder='../frontend/dist')
CORS(app)

# 获取系统信息
def get_system_info():
    """获取系统基本信息"""
    try:
        username = os.environ.get('USER', os.environ.get('USERNAME', 'unknown'))
        hostname = socket.gethostname()
        os_version = platform.platform()
        
        # 网络状态
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=2)
            network_status = "Connected"
        except:
            network_status = "Disconnected"
        
        return {
            'username': username,
            'hostname': hostname,
            'os_version': os_version,
            'network_status': network_status,
            'current_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
    except Exception as e:
        return {'error': str(e)}

def run_lsf_command(cmd):
    """执行 LSF 命令并返回结果"""
    try:
        # Python 2.7.5 兼容的 subprocess 调用
        process = subprocess.Popen(
            cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.PIPE
        )
        stdout, stderr = process.communicate()
        
        if process.returncode != 0:
            return {'success': False, 'error': stderr.decode('utf-8', errors='ignore')}
        
        return {'success': True, 'output': stdout.decode('utf-8', errors='ignore')}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def parse_bjobs(output):
    """解析 bjobs 命令输出"""
    jobs = []
    lines = output.strip().split('\n')
    
    if len(lines) < 2:
        return jobs
    
    # 跳过标题行
    for line in lines[1:]:
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) >= 7:
            jobs.append({
                'job_id': parts[0],
                'user': parts[1],
                'status': parts[2],
                'queue': parts[3],
                'host': parts[4] if len(parts) > 4 else 'N/A',
                'job_name': parts[5] if len(parts) > 5 else 'N/A',
                'slots': parts[6] if len(parts) > 6 else '1'
            })
    
    return jobs

def parse_bhosts(output):
    """解析 bhosts 命令输出"""
    hosts = []
    lines = output.strip().split('\n')
    
    if len(lines) < 2:
        return hosts
    
    for line in lines[1:]:
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) >= 4:
            hosts.append({
                'host_name': parts[0],
                'status': parts[1],
                'r1m': parts[2] if len(parts) > 2 else 'N/A',
                'r15m': parts[3] if len(parts) > 3 else 'N/A'
            })
    
    return hosts

def parse_busers(output):
    """解析 busers 命令输出"""
    users = []
    lines = output.strip().split('\n')
    
    if len(lines) < 2:
        return users
    
    for line in lines[1:]:
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) >= 4:
            users.append({
                'user': parts[0],
                'max': parts[1] if len(parts) > 1 else 'N/A',
                'njobs': parts[2] if len(parts) > 2 else '0',
                'run': parts[3] if len(parts) > 3 else '0'
            })
    
    return users

def parse_bqueues(output):
    """解析 bqueues 命令输出"""
    queues = []
    lines = output.strip().split('\n')
    
    if len(lines) < 2:
        return queues
    
    for line in lines[1:]:
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) >= 5:
            queues.append({
                'queue_name': parts[0],
                'status': parts[1],
                'max': parts[2] if len(parts) > 2 else 'N/A',
                'njobs': parts[3] if len(parts) > 3 else '0',
                'run': parts[4] if len(parts) > 4 else '0'
            })
    
    return queues

def parse_lsload(output):
    """解析 lsload 命令输出用于趋势图"""
    loads = []
    lines = output.strip().split('\n')
    
    if len(lines) < 2:
        return loads
    
    for line in lines[1:]:
        if not line.strip():
            continue
        
        parts = line.split()
        if len(parts) >= 8:
            loads.append({
                'host': parts[0],
                'r1m': float(parts[2]) if len(parts) > 2 and parts[2] != '-' else 0,
                'r15m': float(parts[4]) if len(parts) > 4 and parts[4] != '-' else 0,
                'utotal': float(parts[6]) if len(parts) > 6 and parts[6] != '-' else 0
            })
    
    return loads

@app.route('/')
def index():
    """返回前端页面"""
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/system-info')
def api_system_info():
    """获取系统信息"""
    return jsonify(get_system_info())

@app.route('/api/jobs')
def api_jobs():
    """获取作业列表"""
    result = run_lsf_command('bjobs -w')
    if result['success']:
        jobs = parse_bjobs(result['output'])
        return jsonify({'success': True, 'data': jobs})
    return jsonify(result)

@app.route('/api/hosts')
def api_hosts():
    """获取主机列表"""
    result = run_lsf_command('bhosts -w')
    if result['success']:
        hosts = parse_bhosts(result['output'])
        return jsonify({'success': True, 'data': hosts})
    return jsonify(result)

@app.route('/api/users')
def api_users():
    """获取用户列表"""
    result = run_lsf_command('busers -w')
    if result['success']:
        users = parse_busers(result['output'])
        return jsonify({'success': True, 'data': users})
    return jsonify(result)

@app.route('/api/queues')
def api_queues():
    """获取队列列表"""
    result = run_lsf_command('bqueues -w')
    if result['success']:
        queues = parse_bqueues(result['output'])
        return jsonify({'success': True, 'data': queues})
    return jsonify(result)

@app.route('/api/load')
def api_load():
    """获取负载信息"""
    result = run_lsf_command('lsload -w')
    if result['success']:
        loads = parse_lsload(result['output'])
        return jsonify({'success': True, 'data': loads})
    return jsonify(result)

@app.route('/api/job/<job_id>')
def api_job_detail(job_id):
    """获取作业详细信息"""
    result = run_lsf_command('bjobs -l %s' % job_id)
    if result['success']:
        return jsonify({'success': True, 'data': result['output']})
    return jsonify(result)

@app.route('/api/kill/<job_id>', methods=['POST'])
def api_kill_job(job_id):
    """终止作业"""
    result = run_lsf_command('bkill %s' % job_id)
    return jsonify(result)

@app.route('/api/load-trend')
def api_load_trend():
    """获取负载趋势数据（模拟历史数据）"""
    import random
    from datetime import timedelta
    
    result = run_lsf_command('lsload -w')
    current_loads = []
    if result['success']:
        current_loads = parse_lsload(result['output'])
    
    # 生成过去 1 小时的趋势数据（每 5 分钟一个点）
    trend_data = []
    hosts = set([load['host'] for load in current_loads]) if current_loads else ['localhost']
    
    for i in range(12):  # 12 个点 = 1 小时
        time_point = (datetime.now() - timedelta(minutes=(11-i)*5)).strftime('%H:%M')
        for host in hosts:
            # 模拟一些波动
            base_load = 2.0 + random.random() * 3.0
            trend_data.append({
                'time': time_point,
                'host': host,
                'r1m': round(base_load + random.random(), 2),
                'r15m': round(base_load + random.random() * 0.5, 2)
            })
    
    return jsonify({'success': True, 'data': trend_data})

if __name__ == '__main__':
    # Python 2.7.5 兼容的启动方式
    print("Starting LSF Dashboard Server...")
    print("Access at: http://localhost:5002")
    app.run(host='0.0.0.0', port=5002, debug=True)
