import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from '../views/Dashboard.vue'
import JobDetail from '../views/JobDetail.vue'

const routes = [
  {
    path: '/',
    name: 'Dashboard',
    component: Dashboard
  },
  {
    path: '/job/:jobId',
    name: 'JobDetail',
    component: JobDetail
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
