<template>
  <div class="dashboard">
    <!-- 顶部信息栏 -->
    <div class="header" v-if="systemInfo">
      <div class="header-title">
        <h1>{{ systemInfo.username }} 的仿真作业监控 - {{ systemInfo.hostname }}</h1>
        <span class="run-value" v-if="users.length > 0">busers RUN 值：{{ totalRunUsers }}</span>
      </div>
      <div class="header-info">
        <div class="info-item">
          <span class="label">日期时间:</span>
          <span class="value">{{ systemInfo.current_time }}</span>
        </div>
        <div class="info-item">
          <span class="label">操作系统:</span>
          <span class="value">{{ systemInfo.os_version }}</span>
        </div>
        <div class="info-item">
          <span class="label">网络状态:</span>
          <span :class="['value', 'status', systemInfo.network_status === 'Connected' ? 'connected' : 'disconnected']">
            {{ systemInfo.network_status }}
          </span>
        </div>
        <button @click="refreshAll" class="refresh-btn" :disabled="loading">
          {{ loading ? '刷新中...' : '刷新' }}
        </button>
      </div>
    </div>

    <!-- 主内容区 -->
    <div class="content">
      <!-- 作业列表 -->
      <div class="card jobs-card">
        <div class="card-header">
          <h2>📋 作业列表 (Jobs)</h2>
          <span class="badge">{{ jobs.length }} 个作业</span>
        </div>
        <div class="card-body">
          <div class="table-container">
            <table class="data-table">
              <thead>
                <tr>
                  <th>JOBID</th>
                  <th>USER</th>
                  <th>STATUS</th>
                  <th>QUEUE</th>
                  <th>HOST</th>
                  <th>JOB_NAME</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="job in jobs" :key="job.job_id">
                  <td>
                    <router-link :to="`/job/${job.job_id}`" class="job-link">
                      {{ job.job_id }}
                    </router-link>
                  </td>
                  <td>{{ job.user }}</td>
                  <td>
                    <span :class="['status-badge', job.status.toLowerCase()]">
                      {{ job.status }}
                    </span>
                  </td>
                  <td>{{ job.queue }}</td>
                  <td>{{ job.host }}</td>
                  <td>{{ job.job_name }}</td>
                  <td>
                    <button @click="viewJob(job.job_id)" class="btn-view">详情</button>
                  </td>
                </tr>
                <tr v-if="jobs.length === 0">
                  <td colspan="7" class="empty-message">暂无作业数据</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- 主机和负载 -->
      <div class="row">
        <div class="card hosts-card">
          <div class="card-header">
            <h2>🖥️ 主机列表 (Hosts)</h2>
            <span class="badge">{{ hosts.length }} 台主机</span>
          </div>
          <div class="card-body">
            <table class="data-table">
              <thead>
                <tr>
                  <th>HOST_NAME</th>
                  <th>STATUS</th>
                  <th>R1M</th>
                  <th>R15M</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="host in hosts" :key="host.host_name">
                  <td>{{ host.host_name }}</td>
                  <td>
                    <span :class="['status-badge', host.status.toLowerCase()]">
                      {{ host.status }}
                    </span>
                  </td>
                  <td>{{ host.r1m }}</td>
                  <td>{{ host.r15m }}</td>
                </tr>
                <tr v-if="hosts.length === 0">
                  <td colspan="4" class="empty-message">暂无主机数据</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="card load-card">
          <div class="card-header">
            <h2>📊 系统负载 (Load)</h2>
          </div>
          <div class="card-body">
            <div ref="loadChart" class="chart-container"></div>
          </div>
        </div>
      </div>

      <!-- 用户和队列 -->
      <div class="row">
        <div class="card users-card">
          <div class="card-header">
            <h2>👥 用户列表 (Users)</h2>
          </div>
          <div class="card-body">
            <table class="data-table">
              <thead>
                <tr>
                  <th>USER</th>
                  <th>MAX</th>
                  <th>NJOBS</th>
                  <th>RUN</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="user in users" :key="user.user">
                  <td>{{ user.user }}</td>
                  <td>{{ user.max }}</td>
                  <td>{{ user.njobs }}</td>
                  <td>{{ user.run }}</td>
                </tr>
                <tr v-if="users.length === 0">
                  <td colspan="4" class="empty-message">暂无用户数据</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="card queues-card">
          <div class="card-header">
            <h2>📁 队列列表 (Queues)</h2>
          </div>
          <div class="card-body">
            <table class="data-table">
              <thead>
                <tr>
                  <th>QUEUE_NAME</th>
                  <th>STATUS</th>
                  <th>MAX</th>
                  <th>NJOBS</th>
                  <th>RUN</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="queue in queues" :key="queue.queue_name">
                  <td>{{ queue.queue_name }}</td>
                  <td>
                    <span :class="['status-badge', queue.status.toLowerCase()]">
                      {{ queue.status }}
                    </span>
                  </td>
                  <td>{{ queue.max }}</td>
                  <td>{{ queue.njobs }}</td>
                  <td>{{ queue.run }}</td>
                </tr>
                <tr v-if="queues.length === 0">
                  <td colspan="5" class="empty-message">暂无队列数据</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- 负载趋势图 -->
      <div class="card trend-card">
        <div class="card-header">
          <h2>📈 负载趋势 (Load Trend)</h2>
        </div>
        <div class="card-body">
          <div ref="trendChart" class="chart-container-large"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { useLsfStore } from '../store'
import * as echarts from 'echarts'

export default {
  name: 'Dashboard',
  setup() {
    const router = useRouter()
    const store = useLsfStore()
    const loadChart = ref(null)
    const trendChart = ref(null)

    const {
      systemInfo, jobs, hosts, users, queues, load, loadTrend, loading,
      totalRunUsers
    } = computed(() => ({
      systemInfo: store.systemInfo,
      jobs: store.jobs,
      hosts: store.hosts,
      users: store.users,
      queues: store.queues,
      load: store.load,
      loadTrend: store.loadTrend,
      loading: store.loading,
      totalRunUsers: store.totalRunUsers
    }))

    const refreshAll = async () => {
      await store.refreshAll()
      initCharts()
    }

    const viewJob = (jobId) => {
      router.push(`/job/${jobId}`)
    }

    const initLoadChart = () => {
      if (!loadChart.value || load.value.length === 0) return

      const chart = echarts.init(loadChart.value)
      const hosts = load.value.map(l => l.host)
      const r1mData = load.value.map(l => l.r1m)
      const r15mData = load.value.map(l => l.r15m)

      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'shadow' }
        },
        legend: {
          data: ['1 分钟负载', '15 分钟负载'],
          textStyle: { color: '#333' }
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: hosts,
          axisLabel: {
            interval: 0,
            rotate: 30
          }
        },
        yAxis: {
          type: 'value',
          name: '负载值'
        },
        series: [
          {
            name: '1 分钟负载',
            type: 'bar',
            data: r1mData,
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: '#83bff6' },
                { offset: 1, color: '#188df0' }
              ])
            }
          },
          {
            name: '15 分钟负载',
            type: 'bar',
            data: r15mData,
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: '#a8e6cf' },
                { offset: 1, color: '#34a853' }
              ])
            }
          }
        ]
      }

      chart.setOption(option)
    }

    const initTrendChart = () => {
      if (!trendChart.value || loadTrend.value.length === 0) return

      const chart = echarts.init(trendChart.value)
      
      // 按主机分组数据
      const hostData = {}
      loadTrend.value.forEach(item => {
        if (!hostData[item.host]) {
          hostData[item.host] = []
        }
        hostData[item.host].push(item)
      })

      const series = Object.keys(hostData).map(host => ({
        name: host,
        type: 'line',
        data: hostData[host].map(d => d.r1m),
        smooth: true
      }))

      const option = {
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: Object.keys(hostData),
          textStyle: { color: '#333' }
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: loadTrend.value.filter((v, i, a) => 
            a.findIndex(item => item.time === v.time) === i
          ).map(d => d.time)
        },
        yAxis: {
          type: 'value',
          name: '负载值'
        },
        series: series
      }

      chart.setOption(option)
    }

    const initCharts = async () => {
      await nextTick()
      initLoadChart()
      initTrendChart()
    }

    onMounted(async () => {
      await refreshAll()
      
      // 每 30 秒自动刷新
      setInterval(async () => {
        await store.fetchJobs()
        await store.fetchHosts()
        await store.fetchUsers()
        await store.fetchQueues()
        await store.fetchLoad()
        initCharts()
      }, 30000)
    })

    return {
      systemInfo,
      jobs,
      hosts,
      users,
      queues,
      load,
      loadTrend,
      loading,
      totalRunUsers,
      refreshAll,
      viewJob,
      loadChart,
      trendChart
    }
  }
}
</script>

<style scoped>
.dashboard {
  padding: 20px;
  max-width: 1600px;
  margin: 0 auto;
}

.header {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.header-title {
  margin-bottom: 15px;
}

.header-title h1 {
  color: #333;
  font-size: 24px;
  margin-bottom: 10px;
}

.run-value {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 8px 16px;
  border-radius: 20px;
  font-weight: bold;
  display: inline-block;
}

.header-info {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  align-items: center;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 8px;
}

.label {
  color: #666;
  font-weight: bold;
}

.value {
  color: #333;
}

.status.connected {
  color: #34a853;
  font-weight: bold;
}

.status.disconnected {
  color: #ea4335;
  font-weight: bold;
}

.refresh-btn {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 10px 24px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: bold;
  transition: transform 0.2s;
}

.refresh-btn:hover {
  transform: translateY(-2px);
}

.refresh-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.content {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}

@media (max-width: 1200px) {
  .row {
    grid-template-columns: 1fr;
  }
}

.card {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 12px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.card-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 15px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-header h2 {
  font-size: 18px;
  margin: 0;
}

.badge {
  background: rgba(255, 255, 255, 0.2);
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 14px;
}

.card-body {
  padding: 20px;
}

.table-container {
  overflow-x: auto;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
}

.data-table th,
.data-table td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid #eee;
}

.data-table th {
  background: #f8f9fa;
  color: #333;
  font-weight: bold;
}

.data-table tr:hover {
  background: #f8f9fa;
}

.job-link {
  color: #667eea;
  text-decoration: none;
  font-weight: bold;
}

.job-link:hover {
  text-decoration: underline;
}

.status-badge {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: bold;
  display: inline-block;
}

.status-badge.run {
  background: #d4edda;
  color: #155724;
}

.status-badge.pend {
  background: #fff3cd;
  color: #856404;
}

.status-badge.done {
  background: #d1ecf1;
  color: #0c5460;
}

.status-badge.exit {
  background: #f8d7da;
  color: #721c24;
}

.status-badge.ok {
  background: #d4edda;
  color: #155724;
}

.btn-view {
  background: #667eea;
  color: white;
  border: none;
  padding: 6px 16px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
}

.btn-view:hover {
  background: #5568d3;
}

.empty-message {
  text-align: center;
  color: #999;
  padding: 40px !important;
}

.chart-container {
  height: 300px;
  width: 100%;
}

.chart-container-large {
  height: 400px;
  width: 100%;
}
</style>
